﻿$urifile7z = "http://www.7-zip.org/a/7z1604.msi"
$urifileJRE = "http://javadl.oracle.com/webapps/download/AutoDL?BundleId=235727_2787e4a523244c269598db4e85c51e0c"
$urifileElastick = "https://artifacts.elastic.co/downloads/elasticsearch/elasticsearch-5.6.12.zip"
Configuration PrepareElastickSearch
{
    param 
    ( 
        $NodeName,
        $cred
    )

    $pathmy = 'C:\Program Files'
    Import-DscResource –ModuleName 'PSDesiredStateConfiguration'
    Import-DscResource –ModuleName 'xPSDesiredStateConfiguration'

    Node $NodeName
    { 

        Script TLS 
        {
            GetScript  = { }  #Something     
            SetScript  = {[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12}
            TestScript = {$false}
        }

        LocalConfigurationManager{RebootNodeIfNeeded = $False;}

        File CreateFolder
        {
            DestinationPath = "$pathmy"
            Type = 'Directory'
            Ensure = 'Present'
        }
        File CreateFolderJava
        {
            DestinationPath = "$pathmy\jre-8u192-windows-x64\"
            Type = 'Directory'
            Ensure = 'Present'
        }
        File CreateFolderElastick
        {
            DestinationPath = "$pathmy\ElastickSearch"
            Type = 'Directory'
            Ensure = 'Present'
        }
         xRemoteFile Zip {
            DestinationPath = "$pathmy\Temp\7z1604.msi"
            Uri             = $urifile7z
        }
         xRemoteFile Jre {
            DestinationPath = "$pathmy\Temp\jre-8u192-windows-x64.exe"
            Uri             = $urifileJRE
            dependson = '[Package]7zipArchive'
        }
         xRemoteFile ElastickSearch {
            DestinationPath = "$pathmy\Temp\ElastickSearch.zip"
            Uri             = $urifileElastick
            dependson = '[Package]7zipArchive'
        }
        Package 7zipArchive {
            Ensure    = "Present"  
            Path      = "$pathmy\Temp\7z1604.msi"
            Name      = '7-Zip 16.04'
            ProductId = ''
            Arguments = "/q /norestart"
          
        }

        Script ExtractElastickSearch {

            GetScript  = { }  #Something     
            SetScript  = {
                $DestinationElastickSearch = "$using:pathmy\ElastickSearch\"
                $PathElastickSearch = "$using:pathmy\Temp\ElastickSearch.zip"
                $7z_Application = "C:\Program Files (x86)\7-Zip\7z.exe"
                & $7z_Application 'x' "`"-o$($DestinationElastickSearch)`"" "`"$($PathElastickSearch)`""
            }
            TestScript = {Test-Path "$using:pathmy\ElastickSearch\elasticsearch-5.6.12\bin\elasticsearch-service.bat"}

        }
        Package JreInstall 
        {
            Ensure    = "Present" 
            Path      = "$pathmy\Temp\jre-8u192-windows-x64.exe"
            Name      = 'Java 8 Update 191 (64-bit)'
            ProductId = ''
            Arguments = "/s INSTALLDIR=`"$pathmy\jre-8u192-windows-x64\`" STATIC=1"            
        }
        Script ElastickSearchInstall {

            GetScript  = { }  #Something     
            SetScript  = {
                [Environment]::SetEnvironmentVariable("JAVA_HOME","$using:pathmy\jre-8u192-windows-x64", [System.EnvironmentVariableTarget]::User)
                # & "$using:pathmy\ElastickSearch\elasticsearch-5.6.12\bin\elasticsearch.bat"  
                & "$using:pathmy\ElastickSearch\elasticsearch-5.6.12\bin\elasticsearch-service.bat" 'instal' 
                & "$using:pathmy\ElastickSearch\elasticsearch-5.6.12\bin\elasticsearch-service.bat" 'start'
            }
            TestScript = {$false}
            Credential = $cred 
     }
        
    }

}


Configuration InstallElastickSearch
{
    param 
    ( 
        $NodeName
    )

    $pathmy = 'C:\Program Files'
    Import-DscResource –ModuleName 'PSDesiredStateConfiguration'
    Import-DscResource –ModuleName 'xPSDesiredStateConfiguration'

    Node $NodeName
    {

    Script ElastickSearchInstall {

            GetScript  = { }  #Something     
            SetScript  = {
            [Environment]::SetEnvironmentVariable("$using:pathmy\jre-8u192-windows-x64", $env:JAVA_HOME, [System.EnvironmentVariableTarget]::Machine)
                & "$using:pathmy\ElastickSearch\elasticsearch-5.6.12\bin\elasticsearch.bat"  
                # & "$using:pathmy\ElastickSearch\elasticsearch-5.6.12\bin\elasticsearch-service.bat" 'instal' 
                & "$using:pathmy\ElastickSearch\elasticsearch-5.6.12\bin\elasticsearch-service.bat" 'start'
            }
            TestScript = {$false}
            Credential = $cred 
     }

  }

}
